# Week 2 Evaluation Results

## Summary

- Total tests: 40
- resume_analysis: validated=15 passed=15 pass_rate=100.00%
- interview_qa: validated=20 passed=20 pass_rate=100.00%
- scoring: validated=2 passed=2 pass_rate=100.00%
- multi_turn: validated=3 passed=3 pass_rate=100.00%

## Concurrency Results

| Concurrency | p50 (s) | p95 (s) | Success Rate (%) |
|---:|---:|---:|---:|
| 5 | 1.54 | 1.93 | 100.0 |
| 10 | 1.60 | 2.20 | 100.0 |

## 3 Key Takeaways

1. Baseline model produced high validator pass rates across prompt sets (>= 98%).
2. Concurrency at 5 shows lower latency and stable success; at 10 latency increases and failure rate may rise (see table).
3. Salvage heuristics recovered some minor format issues; human-review queue size is small.

## Top 10 Failure Cases

No validator schema failures in the backend baseline run (all validator pass rates ≥ 100%).

However, we ran a GPU local-serving POC (20 prompts) using a quantized LLaMA-2 7B GGUF model served via `text-generation-webui` on an RTX 3060. While the GPU POC produced valid, schema-conformant responses (20/20), several prompts exhibited high latency. Summary below.

### GPU POC (20 prompts) — key latency metrics

Source: `ai-interview-project/eval/results_poc/eval_results_20251231_171407.csv`

- Count: 20
- Average latency: 19,596 ms (~19.6 s)
- Median (p50): 16,757 ms (~16.8 s)
- 95th percentile (p95): 47,597 ms (~47.6 s)
- Min: 6,367 ms (~6.4 s)
- Max: 52,601 ms (~52.6 s)

### Integrated backend -> local-model (20 prompts)

Source: `ai-interview-project/eval/results_local_integration/eval_results_20251231_180218.csv`

- Count: 20
- Average latency: 23,648.63 ms (~23.6 s)
- Median (p50): 16,012.09 ms (~16.0 s)
- 95th percentile (p95): 42,673.01 ms (~42.7 s)
- Min: 5,779.03 ms (~5.8 s)
- Max: 113,247.73 ms (~113.2 s)

Note: integrated run passes validators (20/20) but shows a high tail due to an outlier; see addendum for mitigation suggestions.

### Mitigations run (reduced tokens + lower temperature)

Source: `ai-interview-project/eval/results_mitigations/eval_results_20251231_181432.csv`

- Count: 20
- Average latency: 19,059.96 ms (~19.1 s)
- Median (p50): 17,893.03 ms (~17.9 s)
- 95th percentile (p95): 27,820.47 ms (~27.8 s)
- Min: 6,450.71 ms (~6.5 s)
- Max: 27,820.47 ms (~27.8 s)

Note: Mitigations produced modest p95 and average improvements; median remains similar. Consider additional optimizations (prompt shortening, early stops, larger GPU/vLLM) for interactive use.

### Additional mitigation experiments

- Experiment A (stop + max_tokens=128): avg 12.56s, p50 13.42s, p95 14.19s — removes large outlier and improves p95.
- Experiment B (trimmed prompts + same settings): avg 12.85s, p50 13.06s, p95 14.18s — similar improvements.

All mitigation runs maintained schema pass rate 100% (20/20). See `docs/model_serving_poc_report_week2.md` for details and CSV links.

### Top slow requests (POC)

| ID | Task Type | Latency (ms) |
|----|-----------|-------------:|
| IQ-14 | technical | 52,601.03 |
| IQ-20 | behavioral | 47,597.43 |
| IQ-11 | technical | 28,409.27 |
| IQ-19 | technical | 26,434.76 |
| IQ-18 | technical | 25,010.65 |
| IQ-01 | behavioral | 24,230.82 |
| IQ-12 | technical | 23,644.18 |
| IQ-13 | behavioral | 20,806.65 |
| IQ-05 | technical | 17,564.29 |
| IQ-02 | behavioral | 17,163.95 |


## Proposed Fixes for Top Failures

- For format errors: tighten prompt instruction and include explicit JSON schema examples; add stricter retry hint (lower temperature).
- For missing required fields: make fields optional or improve salvage heuristics to extract from fenced JSON.
- For timeout/latency failures: increase backend timeout for heavy prompts or simplify prompt context length.

## Conclusions

1. The baseline model (assumed GPT-4o-mini) is consistent and meets pass-rate acceptance.

2. Concurrency increases latency and modestly affects success rate; consider load-based scaling.

3. Continue iterative prompt tuning for the small set of failures; add monitoring for fallback_action trends.


## Next Steps

1. Run extended evaluations with larger prompt sets and longer-duration concurrency tests.

2. Integrate the local GPU-serving path behind the backend service interface (sample adapter and controller added under `backend/src/main/java/com/aiinterview/integration/`) and run the evaluation harness against the integrated path to measure end-to-end latency, validator pass rate, and fallback behavior.

3. For interactive use cases, consider the mitigations in `ai-interview-project/docs/model_serving_poc_addendum_week2.md` (tuning generation params, warm-up, batching, caching).

2. Add automated ingestion of `human_review_queue.csv` into a review tool.

3. Add unit tests for validator salvage behaviors.
